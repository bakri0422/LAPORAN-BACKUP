<?PHP

$servername = "localhost";
$username = "root";
$password = "";
$db = "kehadiran";

$conn = mysqli_connect ($servername, $username, $password, $db) or die("Unable to connect");

echo "Great Work!!";

?>

<?php
 $sql="SELECT * FROM kelas INNER JOIN student ON kelas.classid=student.classid";
 $data=mysqli_query($sql) or die (mysqli_error);
 
 ?>
 