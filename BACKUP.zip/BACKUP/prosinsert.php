<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Aduan</title>
</head>

<body>
	
	<?php
    include('config.php');
    
    if(isset($_POST['submit'])) {
        
        $idpensyarah = $_POST['idpensyarah'];
        $namapensyarah = $_POST['namapensyarah'];
		$tarikh = $_POST['tarikh'];
		$masa = $_POST['masa'];
        
        $insertQuery = "INSERT INTO pensyarah (idpensyarah, namapensyarah, tarikh, masa) VALUES ('$idpensyarah','$namapensyarah','$tarikh','$masa')";
        
        if (mysqli_query($conn, $insertQuery)) {
            
            echo "Successful";
        }
        else {
            
            echo "Something is wrong".$insertQuery."".mysqli_error($conn);
        }
        
        mysqli_error($conn);
    }
    ?>
    
</body>
</html>