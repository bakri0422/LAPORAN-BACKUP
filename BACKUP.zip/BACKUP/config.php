<?php
  $connect = mysqli_connect('localhost', 'root', '', 'kehadiran') or die('Failed to connect to db....');
?>
