<!DOCTYPE html>
<html>
<head>
	<title>Amali Semester 4 2019</title>
</head>
<style type="text/css">
	body {
		background-color: #ddd;
	}
	table {
		width: 75%;
		margin: 0 auto;
	}
	th {
		background-color: yellow;
	}
	a {
		display: inline-block;
		background-color: cyan;
		padding: 14px 16px;
		text-decoration: none;
	}
	a:hover {
		background-color: orange;
		color: white;
	}
</style>
<body>
	
  <h2 style="text-align: center;">Senarai Kehadiran Pensyarah</h2>
 
	<table border="1" cellpadding="5" cellspacing="0" bgcolor="white">

		<tr>
			<th>id Pensyarah</th>
			<th>Nama Pensyarah</th>
			<th>Tarikh</th>
			<th>Masa</th>
		</tr>
		
		
		<?php
		
		include 'config.php';
			$result = mysqli_query($connect,"SELECT * FROM pensyarah")
					or die(mysqli_error());
			

			while ($res=mysqli_fetch_array($result)) {
				echo "
					<tr>
						<td>".$res['idpensyarah']."</td>
						<td>". $res['namapensyarah'] ."</td>
						<td>". $res['tarikh'] ."</td>
						<td>". $res['masa'] ."</td>
					</tr>
			
						";
			}
		?>
	</table>
	<center><p><a href="tambah.php"><button name='tambah'type="submit">Tambah rekod</button></a></p></center>
</body>
</html>