<html>
	<head>
	<title>Senarai Staf</title>
	</head>
	<style>
	h2 {
		text-align: center;
		padding-top: 20px;
	}
	body {
		background-color: #ccc;
	}
	</style>
	<body>
	<center>
	<h2>Borang Pendaftaran kehadiran</h2>
	<table border=0 cellpadding=5 cellspacing=1 bgcolor=white style="padding:20px;border-top:1px solid black; border-left:2px solid black; border-right:2px solid black; border-bottom:1px solid black; border-radius:10px">
	
	<form action="" method="post">
	<tr>
		<td>ID Pensyarah</td><td>:</td><td> <input type="text" name="idpensyarah" required><br><br></td>
	</tr>
	<tr>
		<td>Nama Pensyarah</td><td>:</td><td> <input type="text" name="namapensyarah" required><br><br></td>
	</tr>
	<tr>
		<td>Tarikh</td><td>:</td><td> <input type="text" name="tarikh" required><br><br></td>
	</tr>
	<tr>
		<td>Masa</td><td>:</td><td> <input type="text" name="masa" required><br><br></td>
	</tr>
	<tr>
		<td colspan=3><center><input type="Submit" name="hantar" value="Hantar"><br></td>
	</tr>
	</form>
	</tr>
	</table>
	</body>

<!--memproses input yang dimasukkan ke dalam db-->
<?php
	include('config.php');
	if (isset($_POST['hantar'])){
	$idstaf=$_POST["idpensyarah"];
	$namastaf=$_POST["namapensyarah"];
	$nokp=$_POST["tarikh"];
	$jabatan=$_POST["masa"];
	
	$add=mysqli_query($connect, "INSERT INTO pensyarah values ('$idpensyarah','$namapensyarah','$tarikh','$masa')");
	header('Location:index.php');
	}
?>
</html>
